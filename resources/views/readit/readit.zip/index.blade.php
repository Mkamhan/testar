@include('readit.layouts.header')
@include('readit.layouts.navbar')
{{-- @include('readit.layouts.menu')
@include('readit.layouts.messages') --}}

@yield('content')

@include('readit.layouts.footer')